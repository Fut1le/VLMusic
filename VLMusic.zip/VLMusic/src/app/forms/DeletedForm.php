<?php
namespace app\forms;

use facade\Json;
use std, gui, framework, app;


class DeletedForm extends AbstractForm
{

    /**
     * @event closeBTN.click-Left 
     */
    function doCloseBTNClickLeft(UXMouseEvent $e = null)
    {
        app()->hideForm('DeletedForm');   //Скрыть форму
    }



    /**
     * @event playBTN.click-Left 
     */
    function doPlayBTNClickLeft(UXMouseEvent $e = null)
    {
        $form = $this->form('MainForm');   //Форма
        
        $form->player->open($form->ini->get('dir').'\\'.$this->listView->selectedItem.'.mp3');  //Открываем выбранную песню
        $form->nameLAB->text = $this->listView->selectedItem;   //Выводим названия
        $form->numberLAB->text = 'NaN';   //Выводим номер
        app()->hideForm('DeletedForm');   //Скрываем форму
    }

    /**
     * @event restoreBTN.click-Left 
     */
    function doRestoreBTNClickLeft(UXMouseEvent $e = null)
    {    
        $form = $this->form('MainForm');   //Форма
        
        $form->listView->items->add($this->listView->selectedItem);  //Добавляем песню в список с песнями
        $this->listView->items->remove($this->listView->selectedItem);   //Удаляем песню из списка удалённых
        
        Json::toFile(getcwd().'\deleted.json',arr::of($this->listView->items));  //"Запоминаем" список удалённых песен в файл
        
        $form->reload();   //Обновление
        $this->toast('Двойное нажатие чтобы восстановить все');   //Уведомление
    }

    /**
     * @event restoreBTN.click-2x 
     */
    function doRestoreBTNClick2x(UXMouseEvent $e = null)
    {    
        $form = $this->form('MainForm');   //Форма
        
        $form->listView->items->add($this->listView->items);   //Добавляем все песни в список песен
        $this->listView->items->clear();   //Удаляем все песни из списка удалённых
        
        Json::toFile(getcwd().'\deleted.json',arr::of($this->listView->items));   //"Запоминаем" список удалённых песен в файл
        
        $form->reload();   //Обновление
    }

}
