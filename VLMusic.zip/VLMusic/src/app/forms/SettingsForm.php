<?php
namespace app\forms;

use std, gui, framework, app;


class SettingsForm extends AbstractForm
{

    /**
     * @event closeBTN.click-Left 
     */
    function doCloseBTNClickLeft(UXMouseEvent $e = null)
    {    
        app()->hideForm('SettingsForm');
    }

    /**
     * @event showing 
     */
    function doShowing(UXWindowEvent $e = null)
    {    
        $ini = $this->form('MainForm')->ini;
        if( $ini->get('volume') == true )
        {
            $this->volume->selected = true;
        }
        
        if( $ini->get('playing') == 'true' )
        {
            $this->playing->selected = true;
            $this->position->enabled = true;
        }
        
        if( $ini->get('position') == 'true' )
        {
            $this->position->selected = true;
        }
        
        if( $ini->get('autoplay') == 'true' )
        {
            $this->autoplay->selected = true;
        }
        
        if( $ini->get('notification') == 'true' )
        {
            $this->notification->selected = true;
            $this->tray->enabled = true;
            $this->custom->enabled = true;
        }
        
        if( $ini->get('not_type') == 'tray' )
        {
            $this->tray->selected = true;
            $this->custom->selected = false;
        }
        
        if( $ini->get('not_type') == 'custom')
        {
            $this->custom->selected = true;
            $this->tray->selected = false;
        }
    }

    /**
     * @event volume.action 
     */
    function doVolumeAction(UXEvent $e = null)
    {    
        $form = $this->form('MainForm');
        if( $e->sender->selected == true )
        {
            $form->ini->set('volume','true');
        }
        else
        {
            $form->ini->remove('volume');
            $form->ini->remove('lastVolume');
        }
    }

    /**
     * @event playing.action 
     */
    function doPlayingAction(UXEvent $e = null)
    {    
        $form = $this->form('MainForm');
        if( $e->sender->selected == true )
        {
            $form->ini->set('playing','true');
            $this->position->enabled = true;
        }
        else
        {
            $form->ini->remove('playing');
            $form->ini->remove('lastPlayed');
            $this->position->selected = false;
            $this->position->enabled = false;
        }
    }

    /**
     * @event position.action 
     */
    function doPositionAction(UXEvent $e = null)
    {    
        $form = $this->form('MainForm');
        if( $e->sender->selected == true )
        {
            $form->ini->set('position','true');
        }
        else
        {
            $form->ini->remove('position');
            $form->ini->remove('lastPosition');
            $form->ini->remove('curTime');
            $form->ini->remove('totalTime');
        }
    }

    /**
     * @event autoplay.action 
     */
    function doAutoplayAction(UXEvent $e = null)
    {    
        $form = $this->form('MainForm');
        if( $e->sender->selected == true )
        {
            $form->ini->set('autoplay','true');
        }
        else
        {
            $form->ini->remove('autoplay');
        }
    }

    /**
     * @event notification.action 
     */
    function doNotificationAction(UXEvent $e = null)
    {    
        $form = $this->form('MainForm');
        if( $e->sender->selected == true )
        {
            $form->ini->set('notification','true');
            $form->ini->set('not_type','custom');
            $this->custom->selected = true;
            $this->tray->selected = false;
            $this->tray->enabled = true;
            $this->custom->enabled = true;
        }
        else
        {
            $form->ini->remove('notification');
            $form->ini->remove('not_type');
            $this->tray->selected = false;
            $this->custom->selected = false;
            $this->tray->enabled = false;
            $this->custom->enabled = false;
        }
    }

    /**
     * @event tray.action 
     */
    function doTrayAction(UXEvent $e = null)
    {    
        $form = $this->form('MainForm');
        if( $e->sender->selected == true )
        {
            $form->ini->set('not_type','tray');
            $this->custom->selected = false;
        }
        else
        {
            $form->ini->set('not_type','custom');
            $this->custom->selected = true;
        }
        
    }

    /**
     * @event custom.action 
     */
    function doCustomAction(UXEvent $e = null)
    {    
        $form = $this->form('MainForm');
        if( $e->sender->selected == true )
        {
            $form->ini->set('not_type','custom');
            $this->tray->selected = false;
        }
        else
        {
            $form->ini->set('not_type','tray');
            $this->tray->selected = true;
        }
    }


    



}
