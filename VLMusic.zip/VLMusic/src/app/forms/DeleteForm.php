<?php
namespace app\forms;

use facade\Json;
use std, gui, framework, app;


class DeleteForm extends AbstractForm
{

    /**
     * @event closeBTN.click-Left 
     */
    function doCloseBTNClickLeft(UXMouseEvent $e = null)
    {
        app()->hideForm('DeleteForm');   //Скрыть форму
    }

    /**
     * @event selected.click-Left 
     */
    function doSelectedClickLeft(UXMouseEvent $e = null)
    {    
        $MainForm = $this->form('MainForm');   //Форма MainForm
        $DeletedForm = $this->form('DeletedForm');   //Форма DeletedForm
        
        $DeletedForm->listView->items->add($MainForm->listView->selectedItem);  //Добавляем выбранную песню в список удалённых
        $MainForm->listView->items->remove($MainForm->listView->selectedItem);   //Удаляем выбранную песню из списка
        Json::toFile('deleted.json',arr::of($DeletedForm->listView->items));   //"Запоминаем" список удалённых песен
        $MainForm->reload();   //Обновление
        $MainForm->toast('Вы можете найти эту(-и) музыку(-и) в меню "Удалённые"');   //Уведомление
        app()->hideForm('DeleteForm');   //Скрываем форму
    }

    /**
     * @event all.click-Left 
     */
    function doAllClickLeft(UXMouseEvent $e = null)
    {
        $MainForm = $this->form('MainForm');   //Форма MainForm
        $DeletedForm = $this->form('DeletedForm');   //Форма DeletedForm
        
        $DeletedForm->listView->items->addAll($MainForm->listView->items);  //Добавляем все песни в список удалённых
        $MainForm->listView->items->clear();  //Удаляем все песни из списка
        Json::toFile('deleted.json',arr::of($DeletedForm->listView->items));  //"Запоминаем" список удалённых песен
        $MainForm->reload();   //Обновление
        $MainForm->toast('Вы можете найти эту(-и) музыку(-и) в меню "Удалённые"');   //Уведомление
        app()->hideForm('DeleteForm');   //Скрываем форму
    }



}
