<?php
namespace app\forms;

use std, gui, framework, app;


class TrayMenu extends AbstractForm
{

    /**
     * @event mouseExit 
     */
    function doMouseExit(UXMouseEvent $e = null)
    {    
        waitAsync(1000, function (){
            app()->hideForm('TrayMenu');
        });
    }

    /**
     * @event playBTN.click-Left 
     */
    function doPlayBTNClickLeft(UXMouseEvent $e = null)
    {
        $this->form('MainForm')->play();   // Играть/Пауза
    }

    /**
     * @event pauseBTN.click-Left 
     */
    function doPauseBTNClickLeft(UXMouseEvent $e = null)
    {
        $this->form('MainForm')->play();  // Играть/Пауза
    }

    /**
     * @event stopBTN.click-Left 
     */
    function doStopBTNClickLeft(UXMouseEvent $e = null)
    {
        $this->form('MainForm')->player->stop();   //Останавливаем плеер
        $this->form('MainForm')->curLAB->text = '00:00';   //Сбрасваем плеер
    }

    /**
     * @event rewindBTN.click-Left 
     */
    function doRewindBTNClickLeft(UXMouseEvent $e = null)
    {
        $this->form('MainForm')->listView->selectedIndex -= 1;   //Назад
    }

    /**
     * @event forwardBTN.click-Left 
     */
    function doForwardBTNClickLeft(UXMouseEvent $e = null)
    {
        $this->form('MainForm')->listView->selectedIndex += 1;   //Вперёд
    }


    /**
     * @event posSLIDER.mouseDrag 
     */
    function doPosSLIDERMouseDrag(UXMouseEvent $e = null)
    {
        $this->form('MainForm')->player->position = $this->posSLIDER->value;  //Задаём плееру позицию
    }

    /**
     * @event posSLIDER.mouseDown-Left 
     */
    function doPosSLIDERMouseDownLeft(UXMouseEvent $e = null)
    {
        $this->form('MainForm')->player->position = $this->posSLIDER->value;   //Задаём плееру позицию
    }

    /**
     * @event image3.click-Left 
     */
    function doImage3ClickLeft(UXMouseEvent $e = null)
    {
        $this->form('MainForm')->volumeSwitch();   //Переключение громкости
    }

    /**
     * @event volumeSLIDER.mouseDrag 
     */
    function doVolumeSLIDERMouseDrag(UXMouseEvent $e = null)
    {
        $this->form('MainForm')->volumeSLIDER->value = $this->volumeSLIDER->value;
        $this->form('MainForm')->player->volume = $this->volumeSLIDER->value / 100;
        $this->form('MainForm')->volumeChange();
        $this->form('MainForm')->volumeLAB->text = 'Громкость: '.explode('.',$this->form('MainForm')->player->volume * 100)[0] .'%';   //Выводим громкость в label;
    }

    /**
     * @event volumeSLIDER.mouseDown-Left 
     */
    function doVolumeSLIDERMouseDownLeft(UXMouseEvent $e = null)
    {
        $this->form('MainForm')->volumeSLIDER->value = $this->volumeSLIDER->value;
    }




}
