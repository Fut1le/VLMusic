<?php
namespace app\forms;

use facade\Json;
use std, gui, framework, app;


class MainForm extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->loadIcons();   //Загрузка иконок
        $this->reload();   //Обновление
        $this->loadSettings();   //Загрузка настроек
    }   
    

    /**
     * @event closeBTN.click-Left 
     */
    function doCloseBTNClickLeft(UXMouseEvent $e = null)
    {    
        app()->shutdown();   //Закрыть приложение
    }

    /**
     * @event hideBTN.click-Left 
     */
    function doHideBTNClickLeft(UXMouseEvent $e = null)
    {    
        $this->iconified = true;   //Свернуть приложение
    }



    /**
     * @event volumeSLIDER.mouseDrag 
     */
    function doVolumeSLIDERMouseDrag(UXMouseEvent $e = null)
    {    
        $this->volumeChange();   //Изменить громкость
        $this->form('TrayMenu')->volumeSLIDER->value = $this->volumeSLIDER->value;   //Значение слайдера виджета
    }

    /**
     * @event volumeSLIDER.mouseDown-Left 
     */
    function doVolumeSLIDERMouseDownLeft(UXMouseEvent $e = null)
    {    
        $this->volumeChange();   //Изменить громкость
    }

    /**
     * @event image3.click-Left 
     */
    function doImage3ClickLeft(UXMouseEvent $e = null)
    {    
        $this->volumeSwitch();   //Переключение громкости
    }


    /**
     * @event playBTN.click-Left 
     */
    function doPlayBTNClickLeft(UXMouseEvent $e = null)
    {    
        $this->play();   // Играть/Пауза
        $this->player->position = $this->posSLIDER->value;
    }

    /**
     * @event stopBTN.click-Left 
     */
    function doStopBTNClickLeft(UXMouseEvent $e = null)
    {    
        $this->player->stop();   //Останавливаем плеер
        $this->curLAB->text = '00:00';   //Сбрасваем плеер
    }


    /**
     * @event posSLIDER.mouseDrag 
     */
    function doPosSLIDERMouseDrag(UXMouseEvent $e = null)
    {    
        $this->player->position = $this->posSLIDER->value;  //Задаём плееру позицию
        $posMS = $this->player->positionMs / 1000;   //Получаем позицию в секундах
        $pos = sprintf("%02d:%02d", floor($posMS / 60) % 60, $posMS % 60);  //Переводим в формат мм:сс
        $this->curLAB->text = $pos;
    }

    /**
     * @event posSLIDER.mouseDown-Left 
     */
    function doPosSLIDERMouseDownLeft(UXMouseEvent $e = null)
    {    
        $this->player->position = $this->posSLIDER->value;   //Задаём плееру позицию
        $posMS = $this->player->positionMs / 1000;   //Получаем позицию в секундах
        $pos = sprintf("%02d:%02d", floor($posMS / 60) % 60, $posMS % 60);  //Переводим в формат мм:сс
        $this->curLAB->text = $pos;
    }

    /**
     * @event listView.action 
     */
    function doListViewAction(UXEvent $e = null)
    {    
        $this->playSelectedMusic();   //Играть
    }

    /**
     * @event forwardBTN.click-Left 
     */
    function doForwardBTNClickLeft(UXMouseEvent $e = null)
    {    
        $this->listView->selectedIndex += 1;   //Вперёд
    }

    /**
     * @event rewindBTN.click-Left 
     */
    function doRewindBTNClickLeft(UXMouseEvent $e = null)
    {    
        $this->listView->selectedIndex -= 1;   //Назад
    }

    /**
     * @event openFolderBTN.click-Left 
     */
    function doOpenFolderBTNClickLeft(UXMouseEvent $e = null)
    {    
        open($this->ini->get('dir'));   //Открыть папку с файлами
    }

    /**
     * @event playlistBTN.click-Left 
     */
    function doPlaylistBTNClickLeft(UXMouseEvent $e = null)
    {    
        $this->playlistShow();   //Показать плейлист
    }

    /**
     * @event playlist2BTN.click-Left 
     */
    function doPlaylist2BTNClickLeft(UXMouseEvent $e = null)
    {
        $this->playlistHide();   //Показать плейлист
    }

    /**
     * @event deletedBTN.click-Left 
     */
    function doDeletedBTNClickLeft(UXMouseEvent $e = null)
    {
        app()->showForm('DeletedForm');   //Показываем форму
    }

    /**
     * @event reloadBTN.click-Left 
     */
    function doReloadBTNClickLeft(UXMouseEvent $e = null)
    {
        $this->reload();   //Обновление
    }

    /**
     * @event deleteBTN.click-Left 
     */
    function doDeleteBTNClickLeft(UXMouseEvent $e = null)
    {
        if( $this->listView->selectedIndex > -1 )  //Если песня выбрана
        {
            app()->showForm('DeleteForm');  //Показываем форму
            $this->form('DeleteForm')->all->visible = true;
            $this->form('DeleteForm')->selected->visible = true;
        }
        else  //Иначе (если музыка не выбрана)
        {
            if( $this->listView->items->isNotEmpty() )
            {
                app()->showForm('DeleteForm');  //Показываем форму
                $this->form('DeleteForm')->all->visible = true;
                $this->form('DeleteForm')->selected->visible = false;
            }
            else
            {
                $this->form('MainForm')->toast('Список песен пуст');
            }
        }
    }

    /**
     * @event replayBTN.click-Left 
     */
    function doReplayBTNClickLeft(UXMouseEvent $e = null)
    {    
        $this->replay->visible = !$this->replay->visible;  //Переключение видимости
    }

    /**
     * @event pauseBTN.click-Left 
     */
    function doPauseBTNClickLeft(UXMouseEvent $e = null)
    {
        $this->play();  // Играть/Пауза
    }


    /**
     * @event hide 
     */
    function doHide(UXWindowEvent $e = null)
    {    
        $this->systemTray->free();
        app()->shutdown();
        
        $ini = $this->ini;
        if( $ini->get('volume') == 'true' )
        {
            $ini->set('lastVolume',str_replace('.','',substr($this->player->volume * 100,0,2)));
        }
        
        if( $ini->get('playing') == 'true' )
        {
            $ini->set('lastPlayed',$this->nameLAB->text);
        }
        
        if( $ini->get('position') == 'true' )
        {
            $ini->set('lastPosition',$this->posSLIDER->value);
            $ini->set('totalTime',$this->totalLAB->text);
            $ini->set('curTime',$this->curLAB->text);
        }
    }

    /**
     * @event settingsBTN.click-Left 
     */
    function doSettingsBTNClickLeft(UXMouseEvent $e = null)
    {    
        app()->showForm('SettingsForm');
    }

    /**
     * @event posSLIDER.click-Left 
     */
    function doPosSLIDERClickLeft(UXMouseEvent $e = null)
    {    
        $this->player->position = $this->posSLIDER->value;   //Задаём плееру позицию
        $posMS = $this->player->positionMs / 1000;   //Получаем позицию в секундах
        $pos = sprintf("%02d:%02d", floor($posMS / 60) % 60, $posMS % 60);  //Переводим в формат мм:сс
        $this->curLAB->text = $pos;
    }


    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        
    }








    
    
    
    /*
    ****************************************************************************************************
    ****************************************************************************************************
    *********************************************ФУНКЦИИ************************************************
    ****************************************************************************************************
    ****************************************************************************************************
    */
    
    /**
     * Функция обновления таблицы с песнями 
     */
    function reload()   
    {
        $musicList = $this->form('MainForm')->listView;   //Список с песнями
        $deletedList = $this->form('DeletedForm')->listView;   //Список с удалёнными песнями
        $ini = $this->form('MainForm')->ini;   //ini в котором хранится указанная папка
        
        $musicList->items->clear();    //Чистим таблицу с песнями
        fs::scan($ini->get('dir'), function($filename) use($musicList)   //Сканируем ука-ую дир-ию
        { 
            if( fs::ext($filename) == 'mp3' )    //Забираем файлы с расширением .mp3
            { 
                $musicNames = fs::nameNoExt($filename);  //Названия файлов без расширения
                $musicList->items->add($musicNames); //Добавляем названия в таблицу(для сравнения в будущем)
            } 
        },1);
        
        $deletedList->items->clear();  //Очищаем таблицу удалённых песен(для избавления от дубликатов)
        $deletedList->items->addAll(Json::fromFile(getcwd().'\deleted.json')); //"Вспоминаем" список удалённых песен из файла
           
        $deletedItems = $deletedList->items->toArray();   //Массив с удалёнными песнями
        $musicItems = $musicList->items->toArray();   //Массив со всеми песнями
        $result = array_diff($musicItems,$deletedItems);  //Получаем массив с песнями которых нет в таблице удалённых
        
        Json::toFile('deleted.json',arr::of($deletedList->items));   //"Запоминаем" список удалённых песен в файл
        
        $musicList->items->clear();   //Очищаем таблицу ещё раз
        $musicList->items->addAll($result);   //Добавляем только не удалённые песни
        
        $count = $musicList->items->count();   //Получаем кол-во не удалённых песен
        $this->form('MainForm')->countLAB->text = "Всего: $count";   //Выводим кол-во песен
    }
    
    /**
     * Функция загрузки иконок в material кнопки
     */
    function loadIcons()   //Загрузка иконок в material кнопки(потому что в версии 16.7.0 (develnext) иконки загружаются только через код)
    {
        $this->closeBTN->graphic = new UXImageView(new UXImage('res://.data/img/close.png'));
        $this->form('DeletedForm')->closeBTN->graphic = new UXImageView(new UXImage('res://.data/img/close.png'));
        $this->form('DeleteForm')->closeBTN->graphic = new UXImageView(new UXImage('res://.data/img/close.png'));
        $this->form('SettingsForm')->closeBTN->graphic = new UXImageView(new UXImage('res://.data/img/close.png'));
        $this->hideBTN->graphic = new UXImageView(new UXImage('res://.data/img/hide.png'));
        $this->playBTN->graphic = new UXImageView(new UXImage('res://.data/img/play.png'));
        $this->settingsBTN->graphic = new UXImageView(new UXImage('res://.data/img/settings.png'));
        $this->pauseBTN->graphic = new UXImageView(new UXImage('res://.data/img/pause.png'));
        $this->stopBTN->graphic = new UXImageView(new UXImage('res://.data/img/stop.png'));
        $this->forwardBTN->graphic = new UXImageView(new UXImage('res://.data/img/next.png'));
        $this->rewindBTN->graphic = new UXImageView(new UXImage('res://.data/img/prev.png'));
        $this->playlistBTN->graphic = new UXImageView(new UXImage('res://.data/img/playlist.png'));
        $this->playlist2BTN->graphic = new UXImageView(new UXImage('res://.data/img/playlist.png'));
        $this->openBTN->graphic = new UXImageView(new UXImage('res://.data/img/folder.png'));
        $this->reloadBTN->graphic = new UXImageView(new UXImage('res://.data/img/reload.png'));
        $this->deleteBTN->graphic = new UXImageView(new UXImage('res://.data/img/delete.png'));
        $this->replayBTN->graphic = new UXImageView(new UXImage('res://.data/img/replay.png'));
        $this->form('DeletedForm')->playBTN->graphic = new UXImageView(new UXImage('res://.data/img/play.png'));
        $this->form('TrayMenu')->playBTN->graphic = new UXImageView(new UXImage('res://.data/img/play.png'));
        $this->form('TrayMenu')->pauseBTN->graphic = new UXImageView(new UXImage('res://.data/img/pause.png'));
        $this->form('TrayMenu')->stopBTN->graphic = new UXImageView(new UXImage('res://.data/img/stop.png'));
        $this->form('TrayMenu')->rewindBTN->graphic = new UXImageView(new UXImage('res://.data/img/prev.png'));
        $this->form('TrayMenu')->forwardBTN->graphic = new UXImageView(new UXImage('res://.data/img/next.png'));
        $this->form('DeletedForm')->restoreBTN->graphic = new UXImageView(new UXImage('res://.data/img/restore.png'));
    }
    
    /**
     * Функция загрузки настроек
     */
    function loadSettings()
    {
        $ini = $this->ini;  //Сам ини
        
        if( $ini->get('volume') == 'true' )   //Если запоминание громкости включено в настройках
        {
            $this->player->volume = $ini->get('lastVolume') / 100;   //Задаём плееру последнее значение громокости
            $this->volumeSLIDER->value = $ini->get('lastVolume');   //Двигаем слайдер громкости в нужное место
            $this->volumeLAB->text = 'Громкость: '.$ini->get('lastVolume').'%';   //Выводим громоксть в label
        }
        
        if( $ini->get('playing') == 'true' )   //Если запоминание последней песни включено
        {
            $this->player->open($ini->get('dir').'\\'.$ini->get('lastPlayed').'.mp3');   //Открываем песню которая играла последней
            $this->player->stop();   //Останавливаем плеер
            $this->nameLAB->text = $ini->get('lastPlayed');   //Выводим название песни
            
            if( $ini->get('position') == 'true' )  //Здесь же проверяем вкл ли сохранение позиции последней музыки (если вкл то)
            {
                $this->player->position = $ini->get('lastPosition');   //Устанавливаем плееру последнее значение позиции
                $this->posSLIDER->value = $ini->get('lastPosition');   //Двигаем слайдер в нужное место
                $this->curLAB->text = $ini->get('curTime');   //Выводим позицию в ММ:СС
                $this->totalLAB->text = $ini->get('totalTime');   //Выводим длительность в ММ:СС
            }
            else   //Иначе
            {
                $this->player->position = 0;   //Позиция плеера
                $this->posSLIDER->value = 0;   //Позиция слайдера
            }
        }
        
        if( $ini->get('autoplay') == 'true' )   //Если автоплей вкл
        {
            if( $ini->get('playing') == 'true')   //Если сохранена последняя играющая музыка
            {
                $this->player->play();   //Играть
                if( $ini->get('position') == 'true' )   //Если сохранена позиция 
                {
                    $player = $this->player;
                    waitAsync(500, function() use($player,$ini){
                        $player->position = $ini->get('lastPosition');   //Начать с неё
                    });
                }
            }
            else   //Иначе
            {
                $this->listView->selectedIndex = 0;   //Выбрать первую музыку в списке
            }
        }
    }
    
    /**
     * Функция переключения громкости
     */
    function volumeSwitch()
    {
        if( $this->volumeSLIDER->value != 0)  //Если значение слайдера громкости не равно нулю...
        {
            $this->volumeSLIDER->data('lastVolumeValue',$this->volumeSLIDER->value);  //Сохранение последнего значения громкости чтобы потом восстановить
            $this->volumeSLIDER->value = 0;  //Устанавливаем значение слайдера на 0
            $this->form('TrayMenu')->volumeSLIDER->value = 0;  //Устанавливаем значение слайдера на 0
            $this->player->volume = 0;   //Устанавливаем громкость на 0
            $this->volumeLAB->text = 'Громкость: 0%';   //Пишем в тексте значение громкости
            $this->image3->image = new UXImage('res://.data/img/mute.png');   //Новая иконка
            $this->form('TrayMenu')->image3->image = new UXImage('res://.data/img/mute.png');   //Новая иконка
        }
        else //Иначе (если значение слайдера равно 0)...
        {
            $lastVolumeValue = $this->volumeSLIDER->data('lastVolumeValue');   //Получаем ранее сохранённое значение громкости
            $this->volumeSLIDER->value = $lastVolumeValue;   //Устанавливаем значение громкости слайдеру
            $this->form('TrayMenu')->volumeSLIDER->value = $lastVolumeValue;   //Устанавливаем значение громкости слайдеру
            $this->player->volume = substr($lastVolumeValue,0,2);  //Устанавливаем значение громкости плееру
            $value = str_replace('.','',substr($lastVolumeValue,0,2));   //Получаем первые два символа значения
            $this->volumeLAB->text = "Громкость: $value%";   //Выводим значение громкости в label
            $this->image3->image = new UXImage('res://.data/img/volume.png');   //Новая иконка
            $this->form('TrayMenu')->image3->image = new UXImage('res://.data/img/volume.png');   //Изменяем картинку
        }
    }
    
    /**
     * Функция проигрывания выбранной музыки
     */
    function playSelectedMusic()
    {
        if( $this->listView->selectedIndex >= 0 )  //Если музыка выбрана
        {
            $path = $this->ini->get('dir').'\\'.$this->listView->selectedItem.'.mp3';   //Путь к выбранной музыке
        
            $this->player->open($path);    //Открываем выбранную музыку в плеере
        
            $this->nameLAB->text = fs::nameNoExt($path);   //Выводим название файла(песни) из пути без его расширения в label
            $this->numberLAB->text = $this->listView->selectedIndex + 1;   //Выводим номер проигрываемой музыки
        }
    }
    
    /**
     * Функция вкл./выкл. плеера
     */
    function play()   // Вкл./Выкл. плеер
    {
        $player = $this->player;  //Плеер 
        
        if( $player->status == 'PLAYING' )   //Если плеер "поёт"
        {
            $player->pause();   //Пауза
            
        }
        else  //Иначе (если плеер остановлен)
        {
            $player->play();   //Играть
        }
    }
    
    /**
     * Функция показа плейлиста
     */
    function playlistShow()
    {
        $this->height = 464;
        $this->bgRECT->height = 464;
        $this->playlist2BTN->visible = true;
        $this->playlistBTN->visible = false;
    }
    
    /**
     * Функция скрытия плейлиста
     */
    function playlistHide()
    {
        $this->height = 202;
        $this->bgRECT->height = 202;
        $this->playlist2BTN->visible = false;
        $this->playlistBTN->visible = true;
    }
    
    /**
     * Изменение громкости
     */
    function volumeChange()
    {
        $volume = $this->volumeSLIDER->value / 100;   //Делим на значение слайдера на 100 (потому что в плеер громкость считается от 0 до 1)
        $this->player->volume = $volume;   //Задаём громость
        $this->volumeSLIDER->value = $this->player->volume * 100;   //Задаём слайдеру значение громкости плеера * 100 (чтоб как привычно:))
        if( $this->player->volume == 0 )   //Если громкость равна 0
        {
            $this->image3->image = new UXImage('res://.data/img/mute.png');   //Изменяем картинку
            $this->form('TrayMenu')->image3->image = new UXImage('res://.data/img/mute.png');   //Изменяем картинку
        }
        else   //Иначе
        {
            $this->image3->image = new UXImage('res://.data/img/volume.png');   //Изменяем картинку
            $this->form('TrayMenu')->image3->image = new UXImage('res://.data/img/volume.png');   //Изменяем картинку
        }
        $this->volumeLAB->text = 'Громкость: '.explode('.',$this->player->volume * 100)[0] .'%';   //Выводим громкость в label
    } 
}
