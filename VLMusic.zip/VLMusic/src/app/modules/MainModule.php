<?php
namespace app\modules;

use php\desktop\Mouse;
use std, gui, framework, app;


class MainModule extends AbstractModule
{

    /**
     * @event openDLG.action 
     */
    function doOpenDLGAction(ScriptEvent $e = null)
    {    
        $this->player->open($this->openDLG->file);   //Открываем выбранный файл в плеере
        $this->nameLAB->text = fs::nameNoExt($this->openDLG->file);   //Выводим название песни
        $this->numberLAB->text = 'NaN';   //Значение текста
        $this->listView->selectedIndex = -1;   //Удаляем выбор
    }

    /**
     * @event player.play 
     */
    function doPlayerPlay(ScriptEvent $e = null)
    {    
        $this->reloadBTN->enabled = false;  //Запрещаем обновлять список при воспроизведении
        $this->playBTN->visible = false;  //Отключить видимость кнопки Играть
        $this->pauseBTN->visible = true;   //Включить видимость кнопки Пауза
        $this->form('TrayMenu')->playBTN->visible = false;   //Отключить видимость кнопки Играть на виджете
        $this->form('TrayMenu')->pauseBTN->visible = true;   //Включить видимость кнопки Пауза на виджете
        
        $this->form('TrayMenu')->nameLAB->text = '№'.$this->numberLAB->text.'. '.$this->nameLAB->text;   //Название песни на виджет
        
        //Сделал две кнопки пауза\играть потому что с одной баг в эффектах материал (размер не меняется в соответсвии с иконкой)
        
        $this->posSLIDER->value = $this->player->position;   //Присваиваем слайдеру позицию плеера
        $this->form('TrayMenu')->posSLIDER->value = $this->player->position;   //Присваиваем слайдеру виджета позицию плеера
        
        if( $this->curLAB->text == $this->totalLAB->text )   //Если песня проиграна до конца
        {
            if( $this->replay->visible ==  true )   //Если функция replay включена
            {
                $this->posSLIDER->value = 0;   //Значение слайдера на 0
                $this->form('TrayMenu')->posSLIDER->value = 0;   //Значение слайдера на 0
                $this->statusLAB->text = 'Статус: пауза';   //Статус в label
                
                if( $this->listView->selectedIndex != -1 )   //Если музыка выбрана именно в списке
                {
                    $this->listView->selectedIndex = $this->listView->selectedIndex;   //Играем ту же музыку
                }
                if( $this->listView->selectedIndex < 0 )   //Если музыка выбрана отдельно
                {
                    $this->curLAB->text = '00:00';
                    $this->totalLAB->text = 'NaN';
                    $this->pauseBTN->visible = false;
                    $this->playBTN->visible = true;
                    $this->player->stop();
                    $this->player->play();   //Играть 
                }
            }
            
            if( $this->replay->visible == false )   //Если функция replay выключена
            {
                $this->posSLIDER->value = 0;   //Значение слайдера на 0
                $this->form('TrayMenu')->posSLIDER->value = 0;   //Значение слайдера на 0
                $this->player->position = 0;   //Позицию плеера на 0
                $this->curLAB->text = '00:00';   //Сброс счётчика
                $this->totalLAB->text = 'NaN';
                $this->form('TrayMenu')->curLAB->text = '00:00';   //Сброс счётчика
                
                //Перемотка:
                if( $this->listView->selectedIndex < 0 )   //Если музыка выбрана отдельно
                {
                    $this->curLAB->text = '00:00';
                    $this->totalLAB->text = 'NaN';
                    $this->player->stop();
                }
                else
                {
                    if( $this->listView->selectedIndex == $this->listView->items->count() - 1 )   //Если играет последняя песня
                    {
                        $this->listView->selectedIndex = 0;   //Играем первую (потому что дальше песен уже нет)
                        
                    }
                    else   //Иначе (если играет не последняя песня)
                    {
                        $this->listView->selectedIndex = $this->listView->selectedIndex + 1;   //Играем следующую
                        
                        if( $this->ini->get('notification') == 'true' )
                        {
                            if( $this->ini->get('not_type') == 'tray')
                            {
                                waitAsync(500, function (){
                                    $this->systemTray->displayMessage('MP3 Player',$this->nameLAB->text);
                                });
                            }
                            if( $this->ini->get('not_type') == 'custom' )
                            {
                                waitAsync(500, function (){
                                    $this->notificate();
                                });
                            }
                        }
                    } 
                }
                
                
            }
        }
        
        //Громкость
        if( $this->player->volume < 100 )
        {
            $volume = str_replace('.','',substr($this->player->volume * 100,0,2));
        }
        if( $this->volumeSLIDER->value > 99 )
        {
            $volume = str_replace('.','',substr($this->player->volume * 100,0,3));
        }
        
        $this->volumeLAB->text = 'Громкость: '.$volume.'%';   //Выводим громкость в label
        $this->statusLAB->text = 'Статус: играет';    //Выводим статус в label
        
        //Получаем общее длину песни:
        
        $lengthMS = $this->player->media->duration / 1000;   //Получаем длину песни в секундах
        $time = sprintf("%02d:%02d", floor($lengthMS / 60) % 60, $lengthMS % 60);   //Переводим в формат мм:сс
        
        $this->totalLAB->text = $time;   //Выводим длину в label
        $this->form('TrayMenu')->totalLAB->text = $time;   //Выводим длину в label
        
        //Получаем позицию плеера:
        
        $posMS = $this->player->positionMs / 1000;   //Получаем позицию в секундах
        $pos = sprintf("%02d:%02d", floor($posMS / 60) % 60, $posMS % 60);  //Переводим в формат мм:сс
        
        $this->curLAB->text = $pos;   //Выводим позицию в label
        $this->form('TrayMenu')->curLAB->text = $pos;   //Выводим позицию в label
    }
    /**
     * @event player.pause 
     */
    function doPlayerPause(ScriptEvent $e = null)
    {    
        $this->reloadBTN->enabled = true;  //Разрешаем обновлять список при воспроизведении
        $this->playBTN->visible = true;  //Включить видимость кнопки Играть
        $this->pauseBTN->visible = false;   //Отключить видимость кнопки Пауза
        $this->form('TrayMenu')->playBTN->visible = true;   //Включить видимость кнопки Играть на виджете
        $this->form('TrayMenu')->pauseBTN->visible = false;   //Отключить видимость кнопки Пауза на виджете
        
        $this->statusLAB->text = 'Статус: пауза';   //Выводим статус в label
    }

    /**
     * @event player.stop 
     */
    function doPlayerStop(ScriptEvent $e = null)
    {    
        $this->reloadBTN->enabled = true;  //Разрешаем обновлять список при воспроизведении
        $this->playBTN->visible = true;  //Включить видимость кнопки Играть
        $this->pauseBTN->visible = false;   //Отключить видимость кнопки Пауза
        $this->form('TrayMenu')->playBTN->visible = true;   //Включить видимость кнопки Играть на виджете
        $this->form('TrayMenu')->pauseBTN->visible = false;   //Отключить видимость кнопки Пауза на виджете
        
        $this->posSLIDER->value = 0;   //Значение слайдера на 0
        $this->player->position = 0;   //Позицию плеера на 0
        $this->statusLAB->text = 'Статус: пауза';   //Выводим статус в label
    }

    /**
     * @event dirDLG.action 
     */
    function doDirDLGAction(ScriptEvent $e = null)
    {    
        //Назначение папки
        $this->listView->items->clear();   //Очищаем список песен
        
        $this->ini->set('dir',$this->dirDLG->file);   //"Запоминаем" директорию в файл
        $path = $this->ini->get('dir');   //Получаем путь
        
        fs::scan($path, function ($filename, $depth)   //Сканирование директории на файлы
        { 
            if (fs::ext($filename) == 'mp3')   //Сбор файлов с расширение .mp3
            { 
                $name = fs::name($filename);   //Названия песен
                $this->listView->items->add($name);   //Выводим названия песен в список
            } 
        },1);
        
        $this->form('MainForm')->reload();
        $this->countLAB->text = 'Всего: '.$this->listView->items->count();   //Выводим кол-во песен в label
        $this->listView->selectedIndex = 0;   //Выбираем первую песню
        
    }

    /**
     * @event systemTray.click-Left 
     */
    function doSystemTrayClickLeft(UXMouseEvent $e = null)
    {    
        $screen = UXScreen::getPrimary()->bounds;
        $w = $screen['width'];
        $h = $screen['height'];
        app()->showForm('TrayMenu');
        $this->form('TrayMenu')->x = $w - $this->form('TrayMenu')->width;
        $this->form('TrayMenu')->y = $h - $this->form('TrayMenu')->height - 40;
    }

    /**
     * Изменение громкости
     */
    function notificate()
    {
        app()->showForm('NotificationForm')->label->text = $this->nameLAB->text;
        $screen = UXScreen::getPrimary()->bounds;
        $w = $screen['width'];
        $h = $screen['height'];
        
        $this->form('NotificationForm')->x = 0;
        $this->form('NotificationForm')->y = 0;
        $this->form('NotificationForm')->width = $w;
        $this->form('NotificationForm')->label->width = $w - 56;
        $this->form('NotificationForm')->rect->width = $w;
        waitAsync(2500, function (){
            app()->hideForm('NotificationForm');
        });
    }
    

}
